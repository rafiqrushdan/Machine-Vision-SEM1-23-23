# Posture > 2024-01-02 8:03pm
https://universe.roboflow.com/machine-vision-7amjv/posture-smmx5

Provided by a Roboflow user
License: Public Domain

